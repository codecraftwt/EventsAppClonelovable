# Dummy Images for Minneapolis Connect App

This folder contains placeholder images for the app.

## Images needed:
- Profile pictures for users
- Event images (block party, harvest festival, etc.)
- Community group images
- Volunteer activity images
- Dating profile photos
- Resource thumbnails

## Usage:
These images should be replaced with actual images in production.
