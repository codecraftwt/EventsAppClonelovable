import DatesScreen from '@/components/screens/DatesScreen';

export default DatesScreen;
