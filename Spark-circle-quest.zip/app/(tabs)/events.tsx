import EventsScreen from '@/components/screens/EventsScreen';

export default EventsScreen;
