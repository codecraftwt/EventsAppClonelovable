import HomeScreen from '@/components/screens/HomeScreen';

export default HomeScreen;
