import EventDetailsScreen from '@/components/screens/EventDetailsScreen';

export default EventDetailsScreen;
