import ProfileScreen from '@/components/screens/ProfileScreen';

export default ProfileScreen;
