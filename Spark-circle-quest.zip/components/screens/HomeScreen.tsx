import { PostCard } from '@/components/cards/PostCard';
import { CategoryFilter } from '@/components/common/CategoryFilter';
import { Header } from '@/components/common/Header';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { mockGroups, mockPosts } from '@/constants/dataLoader';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function HomeScreen() {
    const colorScheme = useColorScheme();
    const colors = Colors[colorScheme ?? 'light'];
    const [activeCategory, setActiveCategory] = useState('All');

    const categories = ['All', 'Events', 'Jobs', 'Articles', 'Photos'];

    const headerRightActions = (
        <>
            <IconSymbol name="message.fill" size={24} color={colors.text} />
            <IconSymbol name="questionmark.circle.fill" size={24} color={colors.text} />
            <TouchableOpacity onPress={() => router.push('/profile')}>
                <View style={[styles.profilePic, { backgroundColor: colors.tint }]} />
            </TouchableOpacity>
        </>
    );

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
            <Header title="The Minneapolis Feed" rightActions={headerRightActions} />

            <CategoryFilter
                categories={categories}
                activeCategory={activeCategory}
                onCategoryPress={setActiveCategory}
            />

            <ScrollView style={styles.feedContainer}>
                {/* Group Highlights */}
                {mockGroups.map((group) => (
                    <TouchableOpacity key={group.id} style={[styles.groupCard, { backgroundColor: group.color }]}>
                        <View style={styles.groupIcon}>
                            <IconSymbol name={group.icon as any} size={20} color="white" />
                        </View>
                        <View style={styles.groupContent}>
                            <Text style={styles.groupTitle}>{group.name}</Text>
                            <Text style={styles.groupSubtitle}>
                                {group.memberCount} members - {group.newMessages} New Messages
                            </Text>
                        </View>
                        <IconSymbol name="chevron.right" size={20} color="white" />
                    </TouchableOpacity>
                ))}

                {/* Posts */}
                {mockPosts.map((post: any) => (
                    <PostCard
                        key={post.id}
                        post={post}
                        onLike={() => console.log('Like post', post.id)}
                        onComment={() => console.log('Comment on post', post.id)}
                    />
                ))}
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    profilePic: {
        width: 32,
        height: 32,
        borderRadius: 16,
    },
    feedContainer: {
        flex: 1,
        paddingHorizontal: 16,
    },
    groupCard: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        borderRadius: 12,
        marginBottom: 16,
    },
    groupIcon: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    groupContent: {
        flex: 1,
    },
    groupTitle: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600',
        marginBottom: 2,
    },
    groupSubtitle: {
        color: 'white',
        fontSize: 14,
        opacity: 0.8,
    },
});
