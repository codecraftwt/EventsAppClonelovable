import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

interface EventDetailsScreenProps {
    eventId?: string;
}

export default function EventDetailsScreen({ eventId = '1' }: EventDetailsScreenProps) {
    const colorScheme = useColorScheme();
    const colors = Colors[colorScheme ?? 'light'];
    const [isLiked, setIsLiked] = useState(false);

    // Mock event data - in real app, this would come from props or API
    const event = {
        id: '1',
        title: 'Neighborhood Block Party',
        description: 'Join neighbors for food, music, and community connection in a celebration of local unity.',
        date: 'October 13, 2025',
        time: '9:00 AM',
        location: 'Community Center',
        attendees: 290,
        category: 'Community',
        image: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=400&h=200&fit=crop',
        organizer: {
            name: 'Minneapolis Community Events',
            description: 'Organizing community events since 2015',
            image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face'
        },
        attendeeAvatars: [
            'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
            'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
            'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
            'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=50&h=50&fit=crop&crop=face',
        ]
    };

    const handleJoinEvent = () => {
        // Handle join event logic
        console.log('Joining event:', event.id);
    };

    const handleLike = () => {
        setIsLiked(!isLiked);
    };

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
            {/* Header */}
            <View style={[styles.header, { backgroundColor: colors.background }]}>
                <TouchableOpacity onPress={() => router.back()} style={styles.headerButton}>
                    <IconSymbol name="chevron.right" size={24} color={colors.text} />
                </TouchableOpacity>
                <Text style={[styles.headerTitle, { color: colors.text }]}>Event Details</Text>
                <TouchableOpacity style={styles.headerButton}>
                    <IconSymbol name="square.and.arrow.up" size={24} color={colors.text} />
                </TouchableOpacity>
            </View>

            <ScrollView style={styles.scrollContainer}>
                {/* Event Banner Image */}
                <View style={styles.bannerContainer}>
                    <Image source={{ uri: event.image }} style={styles.bannerImage} />

                    {/* Category Tag */}
                    <View style={styles.categoryTag}>
                        <Text style={styles.categoryText}>{event.category}</Text>
                    </View>

                    {/* Like Button */}
                    <TouchableOpacity style={styles.likeButton} onPress={handleLike}>
                        <IconSymbol
                            name={isLiked ? "heart.fill" : "heart"}
                            size={24}
                            color={isLiked ? "#FF3B30" : "white"}
                        />
                    </TouchableOpacity>
                </View>

                {/* Event Information Card */}
                <View style={[styles.card, { backgroundColor: colors.background }]}>
                    <Text style={[styles.eventTitle, { color: colors.text }]}>{event.title}</Text>
                    <Text style={[styles.eventDescription, { color: colors.text }]}>{event.description}</Text>

                    {/* Event Details */}
                    <View style={styles.detailsContainer}>
                        <View style={[styles.detailRow, { backgroundColor: '#F5F5F5' }]}>
                            <IconSymbol name="calendar" size={20} color={colors.text} />
                            <Text style={[styles.detailText, { color: colors.text }]}>{event.date}</Text>
                        </View>

                        <View style={[styles.detailRow, { backgroundColor: '#F5F5F5' }]}>
                            <IconSymbol name="clock.fill" size={20} color={colors.text} />
                            <Text style={[styles.detailText, { color: colors.text }]}>{event.time}</Text>
                        </View>

                        <View style={[styles.detailRow, { backgroundColor: '#F5F5F5' }]}>
                            <IconSymbol name="location.fill" size={20} color={colors.text} />
                            <Text style={[styles.detailText, { color: colors.text }]}>{event.location}</Text>
                        </View>

                        <View style={[styles.detailRow, { backgroundColor: '#F5F5F5' }]}>
                            <IconSymbol name="person.2.fill" size={20} color={colors.text} />
                            <Text style={[styles.detailText, { color: colors.text }]}>{event.attendees} people</Text>
                        </View>
                    </View>

                    {/* Join Event Button */}
                    <TouchableOpacity style={styles.joinButton} onPress={handleJoinEvent}>
                        <Text style={styles.joinButtonText}>Join Event</Text>
                    </TouchableOpacity>
                </View>

                {/* Attendees Section */}
                <View style={[styles.card, { backgroundColor: colors.background }]}>
                    <Text style={[styles.sectionTitle, { color: colors.text }]}>Attendees ({event.attendees})</Text>
                    <View style={styles.attendeesContainer}>
                        {event.attendeeAvatars.map((avatar, index) => (
                            <Image key={index} source={{ uri: avatar }} style={styles.attendeeAvatar} />
                        ))}
                        <View style={styles.moreAttendees}>
                            <Text style={[styles.moreAttendeesText, { color: colors.text }]}>+{event.attendees - 4}</Text>
                        </View>
                    </View>
                </View>

                {/* About the Organizer Section */}
                <View style={[styles.card, { backgroundColor: colors.background }]}>
                    <Text style={[styles.sectionTitle, { color: colors.text }]}>About the Organizer</Text>
                    <View style={styles.organizerContainer}>
                        <Image source={{ uri: event.organizer.image }} style={styles.organizerAvatar} />
                        <View style={styles.organizerInfo}>
                            <Text style={[styles.organizerName, { color: colors.text }]}>{event.organizer.name}</Text>
                            <Text style={[styles.organizerDescription, { color: colors.text }]}>{event.organizer.description}</Text>
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#E0E0E0',
    },
    headerButton: {
        padding: 8,
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    scrollContainer: {
        flex: 1,
    },
    bannerContainer: {
        position: 'relative',
        height: 250,
    },
    bannerImage: {
        width: '100%',
        height: '100%',
    },
    categoryTag: {
        position: 'absolute',
        top: 16,
        right: 16,
        backgroundColor: '#8B5CF6',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 16,
    },
    categoryText: {
        color: 'white',
        fontSize: 14,
        fontWeight: '500',
    },
    likeButton: {
        position: 'absolute',
        top: 16,
        left: 16,
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    card: {
        margin: 16,
        borderRadius: 12,
        padding: 20,
        borderWidth: 1,
        borderColor: '#E0E0E0',
    },
    eventTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 8,
    },
    eventDescription: {
        fontSize: 16,
        lineHeight: 24,
        marginBottom: 20,
    },
    detailsContainer: {
        gap: 12,
        marginBottom: 20,
    },
    detailRow: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 12,
        paddingVertical: 12,
        borderRadius: 8,
        gap: 12,
    },
    detailText: {
        fontSize: 16,
        fontWeight: '500',
    },
    joinButton: {
        backgroundColor: '#8B5CF6',
        paddingVertical: 16,
        borderRadius: 8,
        alignItems: 'center',
    },
    joinButtonText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 16,
    },
    attendeesContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    attendeeAvatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
    },
    moreAttendees: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: '#F0F0F0',
        justifyContent: 'center',
        alignItems: 'center',
    },
    moreAttendeesText: {
        fontSize: 12,
        fontWeight: '500',
    },
    organizerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
    },
    organizerAvatar: {
        width: 60,
        height: 60,
        borderRadius: 30,
    },
    organizerInfo: {
        flex: 1,
    },
    organizerName: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 4,
    },
    organizerDescription: {
        fontSize: 14,
        opacity: 0.7,
    },
});
